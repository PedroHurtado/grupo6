class Customer {
    static get(id){
        return new Promise((resolve /*OK*/,reject /*ERROR*/)=>{
            if(id===1){
                resolve({id})
            }
            else{
                reject("el cliente no existe")
            }
        })
    }
}

class Invoices {
    static get(clientId,){
        return new Promise((resolve,reject)=>{
            if(clientId===1){
                resolve({clientId,invoices:[]})
            }
            else{
                reject("el cliente no tiene facturas")
            }
        })
    }
}

async function main(id){
  try{
    const customer = await Customer.get(id);
    const invoices = await Invoices.get(customer.id)
    console.log(invoices)
  }
  catch(err){
    console.log(err)
  }
  finally{
    console.log("final")
  }
}

main(1)