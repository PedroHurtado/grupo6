class Customer {
    static get(id){
        return new Promise((resolve /*OK*/,reject /*ERROR*/)=>{
            if(id===1){
                resolve({id})
            }
            else{
                reject("el cliente no existe")
            }
        })
    }
}

class Invoices {
    static get(clientId,){
        return new Promise((resolve,reject)=>{
            if(clientId===1){
                resolve({clientId,invoices:[]})
            }
            else{
                reject("el cliente no tiene facturas")
            }
        })
    }
}

function main(id){
    Customer.get(id)
        .then(cliente=>Invoices.get(cliente.id))
        .then(invoices=>console.log(invoices))
        .catch(error=>console.log(error))
        .finally(()=>{console.log("final")})
}

main(2)