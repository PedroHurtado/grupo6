
const template = document.getElementById('calendar')

class Calendar extends HTMLElement{
    _date;
    _shadow;
    constructor(){
        super();
        console.log("constructor")
        this._shadow = this.attachShadow({mode:'closed'})
        this._shadow.appendChild(template.content.cloneNode(true))
        //this.appendChild(template.content.cloneNode(true))
    }

    get date(){
        return this._date;
    }
    set date(value){
        if(value!==this._date){
            this._shadow.appendChild(document.createTextNode(value))
            this._date = value;
        }
    }
    connectedCallback(){
        console.log("connected callback")
        console.log(this._shadow.querySelectorAll('.red'))
    }
    disconnectedCallback(){
        console.log("disconnected callback")
    }
    attributeChangedCallback(name,oldValue,newValue){
        this[name] = newValue;
    }

    static get observedAttributes() { return ['date']; }
}
//prefix-nombre
customElements.define('cxb-calendar', Calendar)