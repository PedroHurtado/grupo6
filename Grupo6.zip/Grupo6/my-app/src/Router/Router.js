import React, { Suspense } from "react";
import { Routes, Route  } from "react-router-dom";
import Layout from './Layout'
/*/import Pagina1 from './pages/Pagina1'
import Pagina2 from './pages/Pagina2'
import Pagina3 from './pages/Pagina3'*/

const Pagina1 = React.lazy(() => import('./pages/Pagina1'))
const Pagina2 = React.lazy(() => import('./pages/Pagina2'))
const Pagina3 = React.lazy(() => import('./pages/Pagina3'))

export default function Router() {
    return (
        
        <Suspense fallback={<div>Loading...</div>}>            
            <Routes>
                <Route path="/" element={<Layout />}>
                    <Route path="/pagina1/:id/ingredients/:ingredientId" element={<Pagina1 />} />
                    <Route path="/pagina2" element={<Pagina2 />} />
                    <Route path="/pagina3" element={<Pagina3 />} />
                </Route>
            </Routes>            
        </Suspense>
        
    )
}