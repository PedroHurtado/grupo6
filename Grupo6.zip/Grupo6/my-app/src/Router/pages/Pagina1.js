import { useParams } from "react-router-dom"
import style from './Pagina1.module.css'
export default function Pagina1(){
    const {id,ingredientId} = useParams();
    return <div className={style.color}>Página1 {id} Ingredient : {ingredientId}</div>
}