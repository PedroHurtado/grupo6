import { useSearchParams } from "react-router-dom"

export default function Pagina2(){
    const [data] = useSearchParams();
    const params = [...data.entries()]
    return <div>
        {
            params.map(p=>(
                <div key={p[0]}>
                    <div>{p[0]}={p[1]}</div>                        
                </div>
            ))
        }
    </div>
}