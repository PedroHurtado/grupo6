export default function Binding(){
    const name = "Pedro Hurtado"
    return (
        <div data-name={name}>{name}</div>
    )
}