/*export default function Conditional(){
    //operador de cortocircuito
    const user="Pedro Hurtado"
    return (
        <>
        {user && <div>{user}</div>}
        {!user && <button>Login</button>}
        </>
    )
}*/

/*export default function Conditional() {
    //operador ternario
    const user = "Pedro";
    return (
        <>
            { user?<div>{ user }</div>: <button>loggin</button>}
        </>
    )
}*/

function getUser(user){
    if(user){
        return <div>{user}</div>
    }
    return <button>Login</button>

}

export default function Conditional() {
    //operador ternario
    const user = undefined;
    return (
        <>
            {getUser(user)}
        </>
    )
}