//import Binding from "./Binding/Binding";
//import Conditional from "./Conditional/Conditional";
//import Collection from "./Collection/Collection";
//import Parent from "./Parent/Parent";
//import Events from "./Events/Events";
//import Calendar from "./Calendar/Calendar";
//import Counter from "./Counter/Counter";
//import StateArray from "./StateArray/StateArray";

//import PerformanceComponent from "./Performance/PerformanceComponent";

import { BrowserRouter } from "react-router-dom";
import Router from "./Router/Router";

//import Timer from "./Timer/Timer";
//import  DateComponent  from "./Hoc/DateComponent";
//import FetchData from "./fetchdata/FetchData";
//import Form from "./Form/Form";







function App() {
  const array=[1,2,3]
  //const date = new Date();
  /*return (
      <BrowserRouter>
        <Router />
      </BrowserRouter>    
    
  )*/

  return (<>
    {array.map(v => <div></div>)}
    </>)
  //return <PerformanceComponent/>

}

export default App;
