export default function Collection() {
    const data = [1, 2, 3];
    return (
        <>
            {data.map(v => <div key={v}>{v}</div>)}
        </>
    )
}