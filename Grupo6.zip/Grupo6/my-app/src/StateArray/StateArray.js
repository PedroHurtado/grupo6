import { useState } from "react";

const initialState = [1,2,3]
export default function StateArray(){
    const [data,setData] = useState(initialState);
    function handlerClick(){
        data.push(data.length+1)
        setData([...data])
       
    }
    return(
        <>
            <button onClick={handlerClick}>Increment Elements</button>
            {data.map(v=><div key={v}>{v}</div>)}
            
        </>
    )
}