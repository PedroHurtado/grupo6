import styles from './Day.module.css'
export default function Day({day}){
    return <div className={styles.day} data-day={day}>{day}</div>
}