import Day from "./Day";
import sytles from './Calendar.module.css'
function*  getDays(){
    for(let i=0;i<31;i++){
        yield i+1;
    }
}

export default function Calendar(){
    const days = [...getDays()]
    function handlerClick(ev){
        ev.stopPropagation();
        const {nativeEvent} =ev;
        const node = nativeEvent.composedPath()
            .find(n=>n.dataset && 'day' in n.dataset)
        if(node){
            const {day} = node.dataset;
            console.log(day)
        }
        
    }
    return (
        <div className={sytles.calendar} onClick={handlerClick}>
            {
                days.map(d=><Day key ={d} day={d}/>)
            }
        </div>
    )
}