import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

let frame;

(function replaceHistory(scope) {
  const pushState = scope.history.pushState
  scope.history.pushState = function(...args){    
    performance.mark('start')
    pushState.apply(scope.history, args)        
    frame=requestIdleCallback(steep)
  }

}(window))

window.addEventListener('popstate', (ev) => { 
  ev.preventDefault(); 
  performance.mark('start')
  frame=requestIdleCallback(steep)
})

function steep(time) {
  performance.mark('end')
  const measure = performance.measure('load','start','end');

  console.log(`${time.timeRemaining()}`)  
  console.log(`${measure.startTime}`)
  console.log(`${measure.duration}`)
  frame && cancelIdleCallback(frame)
  performance.clearMarks();
  performance.clearMeasures();
  //console.trace();
}

performance.mark('start')
frame=requestIdleCallback(steep)

function changes(...args){
  console.log(args[0])
}

const id = document.getElementById('root')
const observerOptions = {
  childList: true,
  subtree: true,
};

const observer = new MutationObserver(changes);
observer.observe(id, observerOptions)

const root = ReactDOM.createRoot(id);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

window.onerror = function(...args){
  console.log(args)
}
window.addEventListener('pageshow',(ev)=>{
  console.log(ev)
})

window.addEventListener('beforeunload', function (e) {
  alert("Pagina descargada")
});

function events(){
  const observer = new PerformanceObserver((list) => {
    list.getEntries().forEach((entry) => {
      // Full duration
      const duration = entry.duration;
  
      // Input delay (before processing event)
      const delay = entry.processingStart - entry.startTime;
  
      // Synchronous event processing time
      // (between start and end dispatch)
      const eventHandlerTime = entry.processingEnd - entry.processingStart;
      console.log(`Total duration: ${duration}`);
      console.log(`Event delay: ${delay}`);
      console.log(`Event handler duration: ${eventHandlerTime}`);
    });
  });
  
  // Register the observer for events
  observer.observe({ type: "event", buffered: true });
  
}

events();

function foo(){
  throw new Error("Error en foo")
}

function bar(){
  foo();
}

bar();

