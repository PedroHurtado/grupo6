import { useMarkFramePaint } from "./usePerformance";
function* generator(){
    for(let i= 0;i<100;i++){
        yield i+1
    }
}
export default function PerformanceComponent(){
    const data = [...generator()]
    useMarkFramePaint({
        markName: 'ItemListRendered',
        /**
         * Signal to the hook that we want to capture the frame right after our item list
         * model is populated.
         */
        enabled: true
    });

    return (
        <ul>            
            {data.map(v=><li key={v}>item {v}</li>)}
        </ul>
    )
}