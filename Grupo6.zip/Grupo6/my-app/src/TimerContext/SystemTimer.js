import { useContext } from "react"
import { CalendarContext } from "./ContextCalendar"

export default function SystemTimer(){
    const date = useContext(CalendarContext);
    return <div>{date}</div>
}