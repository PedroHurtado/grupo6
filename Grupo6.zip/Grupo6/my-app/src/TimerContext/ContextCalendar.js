import  React from 'react'
export const CalendarContext = React.createContext(null);
