export default function SystemDate(){
    return <div>SystemDate</div>
}