import { CalendarContext } from "./ContextCalendar";
import SystemDate from "./SystemDate";
import SystemTimer from "./SystemTimer";
import { useTimer } from "./useTimer";


const initialDate = new Date();
export default function Calendar() {
    const date = useTimer(initialDate)
    return (
        <CalendarContext.Provider value={date}>
            <div>
                <SystemDate />
                <SystemTimer />
            </div>
        </CalendarContext.Provider>
    )
}