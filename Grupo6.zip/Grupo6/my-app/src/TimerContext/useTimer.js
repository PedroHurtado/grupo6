import { useEffect, useState } from "react";

function getTime(date) {
    let options = { hour: 'numeric', minute: 'numeric', second: 'numeric' };
    return new Intl.DateTimeFormat('es-ES', options).format(date);
}

export function useTimer(initialState){
    const [date,setDate] = useState(initialState)
    useEffect(()=>{
        const interval = setInterval(()=>setDate(new Date()),1000)
        return ()=>clearInterval(interval)
    })
    return getTime(date)
}