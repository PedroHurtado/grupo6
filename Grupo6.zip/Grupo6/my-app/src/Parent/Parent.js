import Child from "./Child"
import styles from './Parent.module.css'
export default function Parent() {    
    const data = [{
        id: 1,
        name: 'Pedro',
        phone: 616647015
    },
    {
        id: 2,
        name: 'Pablo',
        phone: 0
    }
    ]
    return (
        <>
            {data.map(v => (
                <Child key={v.id} {...v}>                    
                    <div className={styles.red}>Hello World</div>                                            
                </Child>
            ))}
        </>
    )
}

/*
<Child id={data.id} name={data.name}/>
*/