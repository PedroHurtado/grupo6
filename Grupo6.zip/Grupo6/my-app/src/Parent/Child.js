export default function Child({id,name,children,...rest}){
    //props.name = "Pedro Hurtado" error
   
    return(
        <>
            <div>{id}</div>
            <div>{name}</div>
            {children}
        </>
    )
}