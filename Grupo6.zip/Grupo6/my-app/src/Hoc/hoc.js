class FormatService {

    static getTime(date) {
        let options = { hour: 'numeric', minute: 'numeric', second: 'numeric' };
        return new Intl.DateTimeFormat('es-ES', options).format(date);
    }
    static getDate(date) {
        let options = { weekday: "long", year: 'numeric', month: 'long', day: 'numeric' };
        return new Intl.DateTimeFormat('es-ES', options).format(date);
    }
    static getDateMonth(date) {
        let options = { year: 'numeric', month: 'long' };
        return new Intl.DateTimeFormat('es-ES', options).format(date);
    }
    static getSelectedDate(date) {
        let options = { weekday: 'long', day: 'numeric' };
        return  new Intl.DateTimeFormat('es-ES', options).format(date);
    }
    static getDay(date){
        let options ={day:'numeric'};
        return new Intl.DateTimeFormat('es-ES', options).format(date);
    }
}

function getFormats(){
    const map =new Map();
    map.set(1, FormatService.getTime)
    map.set(2, FormatService.getDate)
    map.set(3, FormatService.getDateMonth)
    map.set(4, FormatService.getSelectedDate)
    return map;

}
export default function hoc(Component){    
    const formats =getFormats();
    return ({format,date})=>{        
        const formatDate = formats.get(format)(date)
        return <Component date={formatDate}/>
    }
}