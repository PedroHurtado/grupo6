import hoc from "./hoc"
function DateComponent({date}){
    return <div>{date}</div>
}

export default hoc(DateComponent)