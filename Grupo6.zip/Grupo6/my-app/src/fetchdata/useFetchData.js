import { useEffect, useState } from "react"

const getData = (url)=>fetch(url)

export function useFetchData(url){
    const [loading,setLoading] = useState(true)
    const [error,setError] = useState(null)
    const [data,setData] = useState([])

    useEffect(()=>{
        getData(url)
        .then(response=>response.json())
        .then(pizzas=>{            
            setData(pizzas)
        })
        .catch(err=>{
            setError(err)
        })
        .finally(()=>{
            setLoading(false)
        })
    },[url])

    return [
        loading,error,data
    ]
}