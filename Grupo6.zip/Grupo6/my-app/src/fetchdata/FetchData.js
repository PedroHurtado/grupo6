import { useFetchData } from "./useFetchData"


export default function FetchData(){

    const [loading,error,data] = useFetchData("data.json")
    
    if(loading){
        return <div>Loading...</div>
    }
    if(error){
        return <div>{error}</div>
    }

    return (
        <>
            {data.map(p=><div key={p.id}>
                  <div>{p.id}</div>  
                  <div>{p.name}</div>    
            </div>)}
        </>
    )
}