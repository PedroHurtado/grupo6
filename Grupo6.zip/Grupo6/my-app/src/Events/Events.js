export default function Events(){
    function handlerClick(ev){
        console.log(ev)
        console.log(ev.nativeEvent)
    }
    return(
        <button onClick={handlerClick}>Click</button>
    )
}