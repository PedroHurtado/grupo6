import { useTimer } from "./useTimer";
import style from './Timer.module.css'

const intitialData = new Date();
export default function Timer(){
    const date = useTimer(intitialData)
    return <div className={style.timer}>{date}</div>
}