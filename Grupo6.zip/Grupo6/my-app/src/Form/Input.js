import { forwardRef } from 'react'
import style from './Input.module.css'
function Input({text,name},ref){
    return <div className={style.control}>
        <label htmlFor={name}>{text}</label>
        <input id={name} name={name} ref = {ref}/>
    </div>
}

export default forwardRef(Input)