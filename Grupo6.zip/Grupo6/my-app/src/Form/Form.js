import { useRef } from "react";
import Input from "./Input";


export default function Form(){
    
    const name = useRef(null)
    const phone = useRef(null)

    function handlerSubmit(ev){
        ev.preventDefault();

        const data = {
            name:name.current.value,
            phone:phone.current.value
        }
        console.log(data)
    }
    return (
        <form onSubmit={handlerSubmit}>

            <Input name="name" text="Introduzca el nombre" ref={name}/>
            <Input name="phone" text="Introduzca el teléfono" ref={phone}/>

            <button type="submit">Enviar</button>

        </form>
    )
}