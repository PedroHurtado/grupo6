export default function Pagina1(){
    console.log("Pagina1")
}