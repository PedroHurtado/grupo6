export default function Pagina2(){
    console.log("Pagina2")
}