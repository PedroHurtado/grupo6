export default function Pagina3(){
    console.log("Pagina3")
}