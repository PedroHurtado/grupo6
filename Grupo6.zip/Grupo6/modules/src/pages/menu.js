function menu(){

        const loadpage = url=>import(url)
        document.addEventListener('click',(ev)=>{
            ev.preventDefault();
            ev.stopPropagation();
            const {target} = ev;
            const page =  target.dataset.page;
            if(page){
                loadpage(`./${page}.js`).then(m=>m.default())
            }
        })
}
menu();