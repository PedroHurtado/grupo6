import pepito, {multiplicacion,suma,resta,divide} from './operaciones.js'
import bar,* as op from './operaciones.js'
import './run.js'
import './pages/menu.js'


console.log(suma(5,3)) //8
console.log(resta(5,3)) //8

console.log(multiplicacion(5,3)) //8
console.log(divide(5,3)) //8

console.log(op.suma(4,4))

pepito();
bar();




