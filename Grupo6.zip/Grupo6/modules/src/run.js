function foo(){
    console.log("run")
}

foo();